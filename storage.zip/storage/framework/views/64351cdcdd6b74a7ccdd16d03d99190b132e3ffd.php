<?php $__env->startSection('sidebar'); ?>

    <div class="container">
        <div class="row">
            <div class="col">
                <h3  style="margin-top: 40px">Edit Profil</h3>

            </div>

        </div>
        <hr>
        <form action="<?php echo e(route('profil.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="row">
            <div class="col">
                <div class="form-group">
                    <label for="foto">Foto Profil</label>
                    <input type="file" class="form-control" id="foto" name="avatar" value="">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <label for="nik">NIK</label>
                <input type="text" name="nik" class="form-control" placeholder="NIK" value="">
            </div>
        </div>
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <label for="nama">Nama</label>
                        <input type="text" name="nama" class="form-control" value="">
                    </div>
                </div>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="gender" id="gender" value="laki-laki">
                <label class="form-check-label" for="gender">
                    Laki - Laki
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="gender" id="genderpr" value="perempuan">
                <label class="form-check-label" for="genderpr">
                    Perempuan
                </label>
            </div>
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <label for="nohp">No HP</label>
                        <input type="text" name="nohp" class="form-control" value="">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label for="alamat">Alamat</label>
                    <div class="form-group">
                        <textarea name="alamat" id="alamat" cols="115" rows="5" class="form-control"></textarea>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </div>
            </div>
        </form>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>