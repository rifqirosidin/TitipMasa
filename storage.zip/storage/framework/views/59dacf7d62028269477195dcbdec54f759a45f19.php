<?php $__env->startSection('content'); ?>
<!-- <style type="text/css">
    a:hover {
        background-color: blue;
    }
</style> -->
<?php echo $__env->make('homepage.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container">
        <h2 class="text-center my-xl-5"><?php echo e($country->name); ?></h2>
        <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="row" id="hover" >
            <div class="col-sm-12">
                <ul class="list-group" style="list-style-type: none;>
                    <li class="text-dark">
                        <a href="<?php echo e(route('trip.profil',[ $trip->id, $trip->user->username])); ?>" class="list-group-item text-dark">

                        <div class="row">
                            <div class="col-sm-1">
                                <img src="<?php echo e(asset('default.png')); ?>" height="80" alt="foto" class="rounded-circle" alt="foto"></div>
                            <div class="col-sm-4"><?php echo e($trip->user->name); ?> <br> <?php echo e($trip->lokasi_destinasi); ?> - <?php echo e($trip->lokasi_pulang); ?>

                                <br>
                            <?php echo e($trip->tgl_pulang); ?></div>
                        </div></a>


                    </li>

         

                </ul>

            </div>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="row float-right" style="margin-top: 30px"">
            <div class="col-sm-12 ">
                <?php echo $trips->links(); ?>

            </div>
        </div>
        
    </div>

<?php $__env->startPush('footer'); ?>
<?php echo $__env->make('homepage.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">

</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>