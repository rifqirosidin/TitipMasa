<?php $__env->startSection('sidebar'); ?>

    <div class="container">
        <div class="row">
            <div class="col">
                <h3  style="margin-top: 40px">Edit Profil</h3>

            </div>

        </div>
        <hr>
        <form action="<?php echo e(route('profil.update', Auth::user()->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <label for="foto">Foto Profil</label>
                        <input type="file" class="form-control" id="foto" name="foto" value="">
                    </div>
                </div>
            </div>
             <div class="row">
                <div class="col">
                    <div class="form-group">
                        <label for="foto">Nama Lengkap</label>
                        <input type="text" class="form-control" id="nama" name="name" value="<?php echo e($user->name); ?>">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label for="nik">Username</label>
                    <input type="text" name="username" class="form-control" placeholder="Username" value="<?php echo e($user->username); ?>">
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <label for="nama">Nama</label>
                        <input type="text" name="nama" class="form-control" value="<?php echo e($user->name); ?>">
                    </div>
                </div>
            </div>
           
            
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <label for="nohp">Phone</label>
                        <input type="text" name="nohp" class="form-control" value="<?php echo e($user->phone); ?>">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label for="alamat">Alamat</label>
                    <div class="form-group">
                        <textarea name="alamat" class="form-control text-left"  id="alamat" cols="115" rows="5" class="form-control">
                     <?php echo e($user->alamat); ?>

                        </textarea>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </div>
            </div>
        </form>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>