<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Titip Masa</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('frontend/homepage/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('frontend/homepage/css/modern-business.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">

</head>

<body>

<!-- Navigation -->
<?php echo $__env->make('homepage.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('homepage.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<!-- Page Content -->
<div class="container">

    <h3 class="my-5" align="center">Trip Internasional</h3>

    <div class="row">
        <?php echo $__env->make('homepage.tap', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
  <!--   <div class="row">
        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-sm-6 portfolio-item text-center">

            <div class="card h-100">
                <a href="<?php echo e(route('list_trip', $country->slug)); ?>"><img class="card-img-top" src="<?php echo e(asset('storage/internasional/' . $country->code . '.jpg')); ?>" alt="Gambar" height="200px"></a>
                <div class="card-body">
                    <h4 class="card-title">
                        <a href="<?php echo e(route('list_trip', $country->slug)); ?>"><?php echo e($country->name); ?></a>
                    </h4>
                    <p class="card-text ">Traveller <?php echo e($country->TripInternational->count()); ?></p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div> -->

<!-- <div class="center">
    <?php echo e($countries->onEachSide(1)->links()); ?>

</div> -->

</div>
<!-- /.container -->

<!-- Footer -->
<footer class="py-5 bg-dark">
    <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Your Website 2018</p>
    </div>
    <!-- /.container -->
</footer>

<!-- Bootstrap core JavaScript -->
<script src="<?php echo e(asset('frontend/homepage/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/homepage/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

</body>

</html>
