<?php $__env->startSection('sidebar'); ?>

    <div class="container">
       
        <div class="row" style="margin-top: 20px">
            <div class="col">
                <a href="<?php echo e(route('profil.edit', $user->id)); ?>" class="btn btn-primary float-right">Edit Profil</a>
                <h2>Profil Saya</h2>
            </div>
        </div>       


        <hr>

        <div class="row">
            <div class="col-sm-3">
                <img src="<?php echo e(asset('storage/'. $user->foto)); ?>" height="100" width="80px" alt="Foto Profil" class="rounded">


            </div>
            <div class="col-sm-6">
                <div class="row">
                    <p>Nama <span style="margin-left: 20px">:</span> <?php echo e($user->name); ?></p>
                </div>
                <div class="row">
                    <p> E-mail <span style="margin-left: 20px">:</span> <?php echo e($user->email); ?></p>
                </div>
                <div class="row">
                    <p>username :  <?php echo e($user->username); ?></p>
                </div>
                <div class="row">
                   <p> No HP<span style="margin-left: 20px">:</span>  <?php echo e($user->phone); ?> </p>
                </div>
                
                <div class="row">
                    <p> Alamat <span style="margin-left: 20px">:</span>  <?php echo e($user->alamat); ?> </p>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>