<?php $__env->startSection('content'); ?>

<?php echo $__env->make('homepage.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container ">
	<h4 class="text-center py-5">Ringkasan Titipan</h4>
	<div class="row">
		<div class="col-sm">
			<table class="table table-striped">
		  <thead>
		    <tr>		  
		      <th scope="col">Nama Barang</th>
		      <th scope="col">Berat Barang</th>
		      <th scope="col">Jumlah</th>
		      <th scope="col">Harga</th>
		      <th scope="col">Total</th>
		    </tr>
		  </thead>
		  <tbody>
		  	<?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    <tr>		     
		      <td><?php echo e($barang->nama_barang); ?></td>
		      <td><?php echo e($barang->berat_barang); ?></td>
		      <td><?php echo e($barang->jumlah); ?></td>
		      <td><?php echo e($barang->harga); ?></td>
		      <td><?php echo e($barang->harga); ?></td>
		    </tr>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    <tr>		    	
		    	<td></td>
		    	<td></td>
		    	<td></td>
		    	<td><strong>Pajak</strong></td>
		    	<td ><?php echo e($barang->pajak); ?></td>
		    </tr>		   
		    <tr>
		    	<td></td>
		    	<td></td>
		    	<td></td>
		    	<td><strong>Total</strong></td>
		    	
		    </tr>
	    
		  </tbody>
		</table>
		<div class="row">
			<div class="col-sm">
				Silahkan tranfer pembayaran sesuai bank dibawah ini
				<h6>Bank Mandiri 166-00-021188803 Atas nama Rifqi Rosidin</h6>
			</div>
			<div class="col-sm">
				<a href="<?php echo e(route('titip.pembayaran', $barang->user->id )); ?>" class="btn btn-primary float-right">Konfirmasi</a>
			</div>
		</div>
		
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>