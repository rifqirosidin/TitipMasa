<br><br>
<div class="container">
    <form method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-group row">
            <label for="name" class="col-sm-2 col-form-label">Name</label>
            <div class="col-sm-10">
                <input type="name" class="form-control <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" placeholder="Name">
                <?php if($errors->has('name')): ?>
                    <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('name')); ?></strong>
            </span>
                <?php endif; ?>
            </div>
        </div>

         <div class="form-group row">
            <label for="username" class="col-sm-2 col-form-label">Username</label>
            <div class="col-sm-10">
                <input id="username" type="text" class="form-control <?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" placeholder="username"required>
                <?php if($errors->has('username')): ?>
                    <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('username')); ?></strong>
            </span>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row">
            <label for="email" class="col-sm-2 col-form-label">Email</label>
            <div class="col-sm-10">
                <input type="email" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" placeholder="Email">
                <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row">
            <label for="password" class="col-sm-2 col-form-label">Password</label>
            <div class="col-sm-10">
                <input id="password" type="password" class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="Password"required>
                <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('password')); ?></strong>
            </span>
                <?php endif; ?>
            </div>
        </div>



        <div class="form-group row">
            <label for="password-confirm" class="col-sm-2 col-form-label">Confirm Password</label>
            <div class="col-sm-10">
                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" placeholder="Confirm Password" required>
            </div>
        </div>

        <div class="form-group row">
            <div class="col-sm-12">
                <button type="submit" class="btn btn-primary float-sm-right">Register</button>
            </div>

        </div>

    </form>

</div>
