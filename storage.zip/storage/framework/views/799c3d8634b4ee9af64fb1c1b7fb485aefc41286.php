<?php $__env->startSection('sidebar'); ?>

<div class="container my-xl-5">
	<div class="row">
		<div class="col-sm-12">
			<table class="table">
  <thead>
    <tr>
      <th scope="col">No</th >
      <th scope="col">Gambar</th>
      <th scope="col">Nama Barang</th>
      <th scope="col">Harga</th>
      <th scope="col">Aksi</th>
     
    </tr>
  </thead>
  <tbody>
    <?php if($penitips->TitipBarang ?? ''): ?>
        <?php $__currentLoopData = $penitips->TitipBarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        	<td><?php echo e($loop->iteration); ?></td>
          <td><img src="<?php echo e(asset('storage/'. $item->gambar_barang)); ?>" height="50" width="100"></td>
          <td><a href=""><?php echo e($item->nama_barang); ?></a></td>
          <td><?php echo e($item->harga); ?></td>
           
        </tr>
       
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <tr>
          <td colspan="3" class="text-center">Tidak ada Titipan</td>
        </tr>
   <?php endif; ?>
  </tbody>
</table>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>