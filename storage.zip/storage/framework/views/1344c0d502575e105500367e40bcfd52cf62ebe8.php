<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('homepage.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container">
        <div class="row" style="margin-top: 50px">
            <div class="col-sm-3 mb-3 my-xl-5">
                <div class="list-group">
                    <a href="" class="list-group-item">Home</a>
                    <a href="<?php echo e(route('trip.create')); ?>" class="list-group-item">Post Trip</a>
                    <a href="<?php echo e(route('profil.index')); ?>" class="list-group-item">Profil</a>
                     <a href="<?php echo e(route('trip.index')); ?> " class="list-group-item">Trips</a>
                    <a href="<?php echo e(route('penitip.index', Auth::user()->id)); ?>" class="list-group-item">Penitip</a>
                    <a href="<?php echo e(route('titipan.index', Auth::user()->id)); ?> " class="list-group-item">Titipan</a>

                </div>
            </div>
            <div class="col-sm-9">
                <?php echo $__env->yieldContent('sidebar'); ?>
            </div>

        </div>


    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>