<?php $__env->startSection('sidebar'); ?>

    <div class="col-md my-xl-5">
        <h1>Halaman Home</h1>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>