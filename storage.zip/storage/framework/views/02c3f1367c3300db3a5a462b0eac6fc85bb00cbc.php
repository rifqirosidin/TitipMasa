<br><br>
<div class="container">
    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group row">
            <label for="email" class="col-sm-2 col-form-label">Email or Username</label>
            <div class="col-sm-10">
                <input type="text" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" placeholder="Email">
                <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group row">
            <label for="password" class="col-sm-2 col-form-label">Password</label>
            <div class="col-sm-10">
                <input type="password" class="form-control" name="password" placeholder="Password">
            </div>
        </div>

        <div class="form-group">
            <div class="col-sm-12"><br>
                <a href="#" class="">Forgot Password?</a>
                <button type="submit" class="btn btn-primary float-sm-right"> Sign in</button>
            </div>

        </div>
    </form>

</div>
