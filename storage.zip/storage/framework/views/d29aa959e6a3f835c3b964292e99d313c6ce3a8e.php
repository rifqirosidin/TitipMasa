<?php $__env->startSection('content'); ?>

<?php echo $__env->make('homepage.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">
	<h3>Team</h3>
	<div class="row" style="margin-bottom: 300px">
		<ul>
			<li>Adityo Satrio Bagaskoro (1202160066)</li>
			<li>Ayuvira Kusuma Muladi (1202164203)</li>
			<li>Hanif Ramadhan  (1202160034)</li>
			<li>Kurnia Dwi Wiranti R  (1202164122)</li>
			<li>Muhammad Fikri Makmur (1202164329)</li>
		</ul>
	</div>
</div>


<?php echo $__env->make('homepage.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>