<?php $__env->startSection('sidebar'); ?>

<div class="container">

        <h2 class="text-center my-xl-5">Daftar Trip</h2>
        <?php $__currentLoopData = $trips->TripInternational; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="row" id="hover" >
            <div class="col-sm-12">
                <ul class="list-group" style="list-style-type: none;>
                    <li class="text-dark">
                        <a href="<?php echo e(route('trip.profil',[ $item->id, $item->user->username ])); ?>" class="list-group-item text-dark">

                        <div class="row">
                            <div class="col-sm-1" style="margin-right: 25px">
                                <img src="<?php echo e(asset('default.png')); ?>" height="80" alt="foto" class="rounded-circle" alt="foto"></div>
                            <div class="col-sm-6"><?php echo e($item->user->name); ?> <br> <?php echo e($item->lokasi_destinasi); ?> - <?php echo e($item->lokasi_pulang); ?>

                                <br>
                            <?php echo e($item->tgl_pulang); ?></div>
                        </div></a>


                    </li>

         

                </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>